let Turtle = require('./turtle').Turtle;
let GalapagosTurtle = require('./galapagos-turtle').GalapagosTurtle;
let WaterTurtle = require('./water-turtle').WaterTurtle;
let EvkodianTurtle = require('./evkodian-turtle').EvkodianTurtle;
let NinjaTurtle = require('./ninja-turtle').NinjaTurtle;


result.Turtle = Turtle;
result.GalapagosTurtle = GalapagosTurtle;
result.WaterTurtle = WaterTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;
