let Employee = require('./employee').Employee;
let Junior = require('./junior').Junior;
let Senior = require('./senior').Senior;
let Manager = require('./manager').Manager;


result.Employee = Employee;
result.Junior = Junior;
result.Senior = Senior;
result.Manager = Manager;
