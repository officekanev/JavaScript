let Person = require('./person').Person;
let Post = require('./post').Post;

result.Person = Person;
result.Post = Post;
