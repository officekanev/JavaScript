let Checkbox = require('./checkbox').Checkbox;
let Numberbox = require('./numberbox').Numberbox;

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;
