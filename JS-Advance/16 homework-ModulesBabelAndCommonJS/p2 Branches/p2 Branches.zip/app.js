let Employee = require('./employee').Employee;
let Branch = require('./branch').Branch;

result.Employee = Employee;
result.Branch = Branch
